import React from "react";

const Home = () => {
    return (
        <div><h1>welcome to home</h1></div>
    )
}

export default Home