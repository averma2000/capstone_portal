import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth } from "../firebaseConfig";

const Register = () => {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [userType, setUserType] = useState("");

	const [confirmpassword, setConfirmPassword] = useState("");

	const navigate = useNavigate();

	useEffect(() => {
		console.log(email, password);
	});

	const handleRegister = () => {
		if (!email || !password || !confirmpassword) {
			alert("Fill all fields");
			return;
		}
		createUserWithEmailAndPassword(auth, email, password)
			.then(async (res) => {
				console.log(res);
				const user = res.user;

				navigate("/");
			})
			.catch((err) => {
				console.log(err.message);
			});
	};

	function handleClick() {
		navigate("/login");
	}

	return (
		<div className="register-form">
			<form>
				<h1>Register</h1>
				<div className="content">
					<div className="input-field">
						<select
							name="userType"
							id="userType"
							value={userType}
							onChange={(e) => setUserType(e.target.value)}
						>
							<option value="group">Group</option>
							<option value="teacher">Teacher</option>
						</select>
					</div>
					<div className="input-field">
						<input
							type="email"
							placeholder="Email"
							autoComplete="nope"
							name="Email"
							id="email"
							value={email}
							onChange={(e) => setEmail(e.target.value)}
						/>
					</div>
					<div className="input-field">
						<input
							type="password"
							placeholder="Password"
							autoComplete="new-password"
							name="password"
							id="password"
							value={password}
							onChange={(e) => setPassword(e.target.value)}
						/>
					</div>
					<div className="input-field">
						<input
							type="password"
							placeholder="Confirm Password"
							autoComplete="new-password"
							name="confirmPassword"
							id="confirmpassword"
							value={confirmpassword}
							onChange={(e) => setConfirmPassword(e.target.value)}
						/>
					</div>
				</div>
				<div className="action">
					<button className="colorHilightBtn" onClick={handleRegister}>
						Register
					</button>
					<button onClick={handleClick}>Sign in</button>
				</div>
			</form>
		</div>
	);
};

export default Register;
